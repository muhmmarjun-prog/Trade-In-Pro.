TRADE IN PRO - ANDROID STUDIO PROJECT

This project wraps the Trade In Pro web prototype inside an Android WebView.
The HTML app is bundled locally, and WebView DOM storage is enabled for localStorage.
No internet permission is declared, so the app is designed for offline use.

HOW TO BUILD AN APK
1. Install Android Studio on a computer.
2. Open this folder (TradeInProAndroid) as an existing project.
3. Let Android Studio sync Gradle; install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.

IMPORTANT
- This is an Android Studio project source, not a compiled APK file.
- Test printing/PDF sharing on the target Android device; WebView behavior can differ from Chrome.
- Keep periodic JSON/CSV backups because clearing app storage or uninstalling can erase local records.
